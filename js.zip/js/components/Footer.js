import React, { Component } from 'react';
import '../../assets/css/footer.css'
export default class Footer extends Component {
  render() {
    return(
        <footer id="footer">
          <p>1902 - 2018 ©NWU<span style={{float: "right"}}>QQ:1480712353</span></p>
        </footer>
    )
  }
}
